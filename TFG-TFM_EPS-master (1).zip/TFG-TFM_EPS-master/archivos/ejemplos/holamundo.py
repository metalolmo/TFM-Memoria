#------------------------------------ -----------------------------------
# helloworld.py
#------------------------------------ -----------------------------------

import stdio

# Write 'Hello, World' to standard output.
stdio.writeln('Hello, World')

#------------------------------------ -----------------------------------

# python helloworld.py
# Hello, World